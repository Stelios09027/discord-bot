const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

// In-memory giveaway store: Map<messageId, giveawayData>
if (!global.giveaways) global.giveaways = new Map();

function parseDuration(str) {
  const units = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  const match = str.match(/^(\d+)([smhd])$/i);
  if (!match) return null;
  return parseInt(match[1]) * units[match[2].toLowerCase()];
}

function formatTimeLeft(ms) {
  if (ms <= 0) return 'Ended';
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

async function endGiveaway(client, giveaway) {
  const { channelId, messageId, winners, prize, hostId } = giveaway;
  try {
    const channel = await client.channels.fetch(channelId);
    const msg = await channel.messages.fetch(messageId);
    const reaction = msg.reactions.cache.get('🎉');

    let participants = [];
    if (reaction) {
      const users = await reaction.users.fetch();
      participants = [...users.values()].filter(u => !u.bot);
    }

    const winnerCount = Math.min(winners, participants.length);
    const picked = [];
    const pool = [...participants];
    for (let i = 0; i < winnerCount; i++) {
      const idx = Math.floor(Math.random() * pool.length);
      picked.push(pool.splice(idx, 1)[0]);
    }

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle(`🎉 Giveaway Ended: ${prize}`)
      .setDescription(picked.length
        ? `🏆 **Winner(s):** ${picked.map(u => u.toString()).join(', ')}\n\nCongratulations!`
        : '❌ No valid participants. No winner selected.')
      .addFields({ name: 'Hosted by', value: `<@${hostId}>`, inline: true })
      .setTimestamp();

    await msg.edit({ embeds: [embed] });

    if (picked.length) {
      channel.send({
        content: `🎉 Congratulations ${picked.map(u => u.toString()).join(', ')}! You won **${prize}**!`,
        embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription(`[Jump to giveaway](${msg.url})`)]
      });
    } else {
      channel.send({ embeds: [client.errorEmbed(`The giveaway for **${prize}** ended with no participants.`)] });
    }

    global.giveaways.delete(messageId);
  } catch (err) {
    console.error('Giveaway end error:', err);
    global.giveaways.delete(messageId);
  }
}

module.exports = {
  name: 'giveaway',
  aliases: ['gw', 'giveway'],
  description: 'Start, end, or reroll a giveaway',
  usage: 'start <duration> <winners>w <prize> | end <messageID> | reroll <messageID> | list',
  permissions: PermissionFlagsBits.ManageGuild,
  category: 'utility',
  cooldown: 5,
  async execute(message, args, client) {
    const sub = args[0]?.toLowerCase();

    // ── giveaway start ──────────────────────────────────────────────
    if (sub === 'start') {
      // ?giveaway start 10m 1w iPhone 15 Pro
      const duration = parseDuration(args[1]);
      if (!duration) return message.reply({ embeds: [client.errorEmbed('Invalid duration. Use: `10m`, `1h`, `2d`')] });

      const winnersArg = args[2]?.match(/^(\d+)w$/i);
      if (!winnersArg) return message.reply({ embeds: [client.errorEmbed('Specify winners like `1w`, `3w`.')] });
      const winners = Math.min(parseInt(winnersArg[1]), 20);

      const prize = args.slice(3).join(' ');
      if (!prize) return message.reply({ embeds: [client.errorEmbed('Please provide a prize name.')] });

      const endsAt = Date.now() + duration;

      const embed = new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle(`🎉 GIVEAWAY: ${prize}`)
        .setDescription(`React with 🎉 to enter!\n\n**Ends:** <t:${Math.floor(endsAt / 1000)}:R>\n**Winners:** ${winners}\n**Hosted by:** ${message.author}`)
        .setFooter({ text: `Ends at` })
        .setTimestamp(endsAt);

      await message.delete().catch(() => {});
      const giveawayMsg = await message.channel.send({ embeds: [embed] });
      await giveawayMsg.react('🎉');

      const giveawayData = {
        messageId: giveawayMsg.id,
        channelId: message.channel.id,
        guildId: message.guild.id,
        prize,
        winners,
        hostId: message.author.id,
        endsAt,
      };

      global.giveaways.set(giveawayMsg.id, giveawayData);

      // Schedule end
      setTimeout(() => endGiveaway(client, giveawayData), duration);

    // ── giveaway end ─────────────────────────────────────────────────
    } else if (sub === 'end') {
      const msgId = args[1];
      if (!msgId) return message.reply({ embeds: [client.errorEmbed('Please provide the giveaway message ID.')] });

      const giveaway = global.giveaways.get(msgId);
      if (!giveaway) return message.reply({ embeds: [client.errorEmbed('No active giveaway found with that ID.')] });

      await endGiveaway(client, giveaway);
      message.reply({ embeds: [client.successEmbed('Giveaway ended!')] });

    // ── giveaway reroll ───────────────────────────────────────────────
    } else if (sub === 'reroll') {
      const msgId = args[1];
      if (!msgId) return message.reply({ embeds: [client.errorEmbed('Please provide the original giveaway message ID.')] });

      try {
        const msg = await message.channel.messages.fetch(msgId);
        const reaction = msg.reactions.cache.get('🎉');
        if (!reaction) return message.reply({ embeds: [client.errorEmbed('No 🎉 reactions found on that message.')] });

        const users = await reaction.users.fetch();
        const participants = [...users.values()].filter(u => !u.bot);
        if (!participants.length) return message.reply({ embeds: [client.errorEmbed('No valid participants to reroll.')] });

        const winner = participants[Math.floor(Math.random() * participants.length)];
        message.channel.send({ content: `🎉 New winner: ${winner}! Congratulations!` });
        message.reply({ embeds: [client.successEmbed(`Rerolled! New winner: **${winner.tag}**`)] });
      } catch {
        message.reply({ embeds: [client.errorEmbed('Could not find that message.')] });
      }

    // ── giveaway list ─────────────────────────────────────────────────
    } else if (sub === 'list') {
      const serverGiveaways = [...global.giveaways.values()].filter(g => g.guildId === message.guild.id);
      if (!serverGiveaways.length) return message.reply({ embeds: [client.infoEmbed('No active giveaways in this server.')] });

      const embed = new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle('🎉 Active Giveaways')
        .setDescription(serverGiveaways.map(g =>
          `**${g.prize}** — ${g.winners} winner(s)\nEnds: <t:${Math.floor(g.endsAt / 1000)}:R> | ID: \`${g.messageId}\``
        ).join('\n\n'));

      message.reply({ embeds: [embed] });

    } else {
      message.reply({ embeds: [new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle('🎉 Giveaway Commands')
        .addFields(
          { name: 'Start', value: '`?giveaway start <duration> <Nw> <prize>`\nExample: `?giveaway start 1h 2w AirPods Pro`' },
          { name: 'End Early', value: '`?giveaway end <messageID>`' },
          { name: 'Reroll', value: '`?giveaway reroll <messageID>`' },
          { name: 'List', value: '`?giveaway list`' },
        )
      ]});
    }
  }
};
