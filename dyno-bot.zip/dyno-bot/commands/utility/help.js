const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const categories = {
  moderation: { emoji: '🛡️', label: 'Moderation' },
  utility: { emoji: '🔧', label: 'Utility' },
  fun: { emoji: '🎉', label: 'Fun' },
  automod: { emoji: '🤖', label: 'AutoMod' },
  settings: { emoji: '⚙️', label: 'Settings' },
};

module.exports = {
  name: 'help',
  aliases: ['h', 'commands', 'cmds'],
  description: 'Show all available commands',
  usage: '[command]',
  async execute(message, args, client) {
    const settings = client.guildSettings.get(message.guild?.id) || { prefix: '?' };
    const prefix = settings.prefix;

    // Specific command help
    if (args[0]) {
      const cmd = client.commands.get(args[0]) || client.commands.find(c => c.aliases?.includes(args[0]));
      if (!cmd) return message.reply({ embeds: [client.errorEmbed(`No command found for \`${args[0]}\`.`)] });

      return message.reply({ embeds: [new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle(`Command: ${prefix}${cmd.name}`)
        .setDescription(cmd.description || 'No description')
        .addFields(
          { name: 'Usage', value: `\`${prefix}${cmd.name} ${cmd.usage || ''}\``.trim(), inline: true },
          { name: 'Aliases', value: cmd.aliases?.map(a => `\`${a}\``).join(', ') || 'None', inline: true },
          { name: 'Cooldown', value: `${cmd.cooldown || 3}s`, inline: true }
        )
      ]});
    }

    // Group commands by folder
    const grouped = {};
    client.commands.forEach(cmd => {
      const cat = cmd.category || 'utility';
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(cmd.name);
    });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('📚 Bot Command List')
      .setDescription(`Prefix: \`${prefix}\` • Use \`${prefix}help <command>\` for details`)
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({ text: `${client.commands.size} total commands` })
      .setTimestamp();

    for (const [cat, cmds] of Object.entries(grouped)) {
      const info = categories[cat] || { emoji: '📦', label: cat };
      embed.addFields({
        name: `${info.emoji} ${info.label}`,
        value: cmds.map(c => `\`${c}\``).join(', '),
        inline: false
      });
    }

    message.reply({ embeds: [embed] });
  }
};
