const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'announce',
  aliases: ['announcement'],
  description: 'Send an announcement embed',
  usage: '[#channel] <message>',
  permissions: PermissionFlagsBits.ManageGuild,
  category: 'utility',
  async execute(message, args, client) {
    const channel = message.mentions.channels.first() || message.channel;
    const content = args.filter(a => !a.startsWith('<#')).join(' ');

    if (!content) return message.reply({ embeds: [client.errorEmbed('Please provide a message.')] });

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('📢 Announcement')
      .setDescription(content)
      .setFooter({ text: `By ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      .setTimestamp();

    await channel.send({ content: '@everyone', embeds: [embed] });
    await message.delete().catch(() => {});
    if (channel.id !== message.channel.id)
      message.reply({ embeds: [client.successEmbed(`Announcement sent to ${channel}.`)] });
  }
};
