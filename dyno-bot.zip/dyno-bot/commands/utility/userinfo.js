const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'userinfo',
  aliases: ['ui', 'whois', 'user'],
  description: 'Get information about a user',
  usage: '[@user]',
  category: 'utility',
  async execute(message, args, client) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    const user = target.user;
    const roles = target.roles.cache.filter(r => r.id !== message.guild.id).sort((a, b) => b.position - a.position);

    const embed = new EmbedBuilder()
      .setColor(target.displayHexColor || '#5865F2')
      .setTitle(user.tag)
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '🆔 User ID', value: user.id, inline: true },
        { name: '🤖 Bot', value: user.bot ? 'Yes' : 'No', inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`, inline: false },
        { name: '📥 Joined Server', value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:F>`, inline: false },
        { name: `🏷️ Roles (${roles.size})`, value: roles.size ? roles.first(10).join(', ') : 'None', inline: false },
        { name: '🏆 Highest Role', value: target.roles.highest.toString(), inline: true },
        { name: '📛 Nickname', value: target.nickname || 'None', inline: true },
      )
      .setFooter({ text: `Requested by ${message.author.tag}` })
      .setTimestamp();

    if (user.banner) embed.setImage(user.bannerURL({ size: 1024 }));

    message.reply({ embeds: [embed] });
  }
};
