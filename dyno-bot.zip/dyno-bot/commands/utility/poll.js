const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'poll',
  description: 'Create a poll with up to 9 options. Separate with |',
  usage: '<question> | <option1> | <option2> ...',
  category: 'utility',
  async execute(message, args, client) {
    const parts = message.content.slice(message.content.indexOf(' ') + 1).split('|').map(s => s.trim());
    const question = parts.shift();
    const options = parts;

    if (!question) return message.reply({ embeds: [client.errorEmbed('Please provide a question.')] });

    const emojis = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣'];

    let description;
    if (!options.length) {
      description = '*React with 👍 or 👎*';
    } else {
      if (options.length > 9) return message.reply({ embeds: [client.errorEmbed('Max 9 options.')] });
      description = options.map((opt, i) => `${emojis[i]} ${opt}`).join('\n\n');
    }

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`📊 ${question}`)
      .setDescription(description)
      .setFooter({ text: `Poll by ${message.author.tag}` })
      .setTimestamp();

    await message.delete().catch(() => {});
    const pollMsg = await message.channel.send({ embeds: [embed] });

    if (!options.length) {
      await pollMsg.react('👍');
      await pollMsg.react('👎');
    } else {
      for (let i = 0; i < options.length; i++) {
        await pollMsg.react(emojis[i]);
      }
    }
  }
};
