const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

// In-memory: Map<guildId, Map<messageId, Map<emoji, roleId>>>
if (!global.reactionRoles) global.reactionRoles = new Map();

module.exports = {
  name: 'reactionrole',
  aliases: ['rr', 'reactrole'],
  description: 'Create or manage reaction role menus',
  usage: 'create <#channel> <title> | add <messageID> <emoji> <@role> | remove <messageID> <emoji> | list',
  permissions: PermissionFlagsBits.ManageRoles,
  category: 'utility',
  async execute(message, args, client) {
    const sub = args[0]?.toLowerCase();
    if (!global.reactionRoles.has(message.guild.id)) global.reactionRoles.set(message.guild.id, new Map());
    const guildRR = global.reactionRoles.get(message.guild.id);

    // ── create ────────────────────────────────────────────────────────
    if (sub === 'create') {
      const channel = message.mentions.channels.first() || message.channel;
      const title = args.filter(a => !a.startsWith('<#')).slice(1).join(' ') || 'React to get a role!';

      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🎭 ' + title)
        .setDescription('React below to receive your role.\n\n*(Roles will appear here after you add them)*')
        .setFooter({ text: 'Reaction Roles' });

      const msg = await channel.send({ embeds: [embed] });
      guildRR.set(msg.id, new Map());

      message.reply({ embeds: [client.successEmbed(`Reaction role panel created in ${channel}!\nMessage ID: \`${msg.id}\`\nNow use: \`reactionrole add ${msg.id} <emoji> @role\``)] });

    // ── add ───────────────────────────────────────────────────────────
    } else if (sub === 'add') {
      const msgId = args[1];
      const emoji = args[2];
      const role = message.mentions.roles.first();

      if (!msgId || !emoji || !role) return message.reply({ embeds: [client.errorEmbed('Usage: `reactionrole add <messageID> <emoji> @role`')] });
      if (!guildRR.has(msgId)) guildRR.set(msgId, new Map());

      const rrMap = guildRR.get(msgId);
      rrMap.set(emoji, role.id);

      // Fetch the message and react + update embed
      try {
        let targetMsg;
        for (const [, ch] of message.guild.channels.cache.filter(c => c.type === 0)) {
          try { targetMsg = await ch.messages.fetch(msgId); break; } catch {}
        }
        if (!targetMsg) return message.reply({ embeds: [client.errorEmbed('Could not find that message.')] });

        await targetMsg.react(emoji);

        // Update embed description
        const entries = [...rrMap.entries()].map(([e, rid]) => `${e} → <@&${rid}>`).join('\n');
        const oldEmbed = targetMsg.embeds[0];
        const updated = EmbedBuilder.from(oldEmbed).setDescription(`React to receive a role:\n\n${entries}`);
        await targetMsg.edit({ embeds: [updated] });

        message.reply({ embeds: [client.successEmbed(`Added: ${emoji} → ${role} to message \`${msgId}\`.`)] });
      } catch (err) {
        message.reply({ embeds: [client.errorEmbed(`Error: ${err.message}`)] });
      }

    // ── remove ────────────────────────────────────────────────────────
    } else if (sub === 'remove') {
      const msgId = args[1];
      const emoji = args[2];
      if (!msgId || !emoji) return message.reply({ embeds: [client.errorEmbed('Usage: `reactionrole remove <messageID> <emoji>`')] });

      const rrMap = guildRR.get(msgId);
      if (!rrMap?.has(emoji)) return message.reply({ embeds: [client.errorEmbed('No reaction role found for that emoji on that message.')] });

      rrMap.delete(emoji);
      message.reply({ embeds: [client.successEmbed(`Removed ${emoji} from message \`${msgId}\`.`)] });

    // ── list ──────────────────────────────────────────────────────────
    } else if (sub === 'list') {
      if (!guildRR.size) return message.reply({ embeds: [client.infoEmbed('No reaction role panels in this server.')] });

      const lines = [];
      for (const [msgId, rrMap] of guildRR) {
        lines.push(`**Message \`${msgId}\`**`);
        if (!rrMap.size) { lines.push('  *(no roles added yet)*'); continue; }
        for (const [emoji, roleId] of rrMap) lines.push(`  ${emoji} → <@&${roleId}>`);
      }

      message.reply({ embeds: [new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🎭 Reaction Role Panels')
        .setDescription(lines.join('\n') || 'None')
      ]});

    } else {
      message.reply({ embeds: [new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🎭 Reaction Role Commands')
        .addFields(
          { name: 'Create Panel', value: '`?reactionrole create [#channel] [title]`' },
          { name: 'Add Role', value: '`?reactionrole add <messageID> <emoji> @role`' },
          { name: 'Remove Role', value: '`?reactionrole remove <messageID> <emoji>`' },
          { name: 'List Panels', value: '`?reactionrole list`' },
        )
      ]});
    }
  }
};
