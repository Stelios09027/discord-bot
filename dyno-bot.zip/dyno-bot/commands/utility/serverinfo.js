const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'serverinfo',
  aliases: ['si', 'guildinfo', 'server'],
  description: 'Get information about the server',
  category: 'utility',
  async execute(message, args, client) {
    const { guild } = message;
    await guild.fetch();

    const owner = await guild.fetchOwner();
    const textChannels = guild.channels.cache.filter(c => c.type === 0).size;
    const voiceChannels = guild.channels.cache.filter(c => c.type === 2).size;
    const categories = guild.channels.cache.filter(c => c.type === 4).size;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const humans = guild.memberCount - bots;

    const verificationLevels = ['None', 'Low', 'Medium', 'High', 'Very High'];

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
      .setDescription(guild.description || '')
      .addFields(
        { name: '🆔 Server ID', value: guild.id, inline: true },
        { name: '👑 Owner', value: owner.user.tag, inline: true },
        { name: '📅 Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: false },
        { name: '👥 Members', value: `Total: ${guild.memberCount}\nHumans: ${humans}\nBots: ${bots}`, inline: true },
        { name: '💬 Channels', value: `Text: ${textChannels}\nVoice: ${voiceChannels}\nCategories: ${categories}`, inline: true },
        { name: '🎭 Roles', value: `${guild.roles.cache.size}`, inline: true },
        { name: '😀 Emojis', value: `${guild.emojis.cache.size}`, inline: true },
        { name: '🔒 Verification', value: verificationLevels[guild.verificationLevel], inline: true },
        { name: '✨ Boost Level', value: `Tier ${guild.premiumTier} (${guild.premiumSubscriptionCount} boosts)`, inline: true },
      )
      .setFooter({ text: `Requested by ${message.author.tag}` })
      .setTimestamp();

    if (guild.bannerURL()) embed.setImage(guild.bannerURL({ size: 1024 }));

    message.reply({ embeds: [embed] });
  }
};
