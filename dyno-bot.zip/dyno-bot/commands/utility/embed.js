const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'embed',
  aliases: ['say'],
  description: 'Send an embedded message',
  usage: '[#channel] <message>',
  permissions: PermissionFlagsBits.ManageMessages,
  category: 'utility',
  async execute(message, args, client) {
    const channel = message.mentions.channels.first() || message.channel;
    const content = args.filter(a => !a.startsWith('<#')).join(' ');

    if (!content) return message.reply({ embeds: [client.errorEmbed('Please provide a message to send.')] });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setDescription(content)
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

    await channel.send({ embeds: [embed] });
    if (channel.id !== message.channel.id) {
      message.reply({ embeds: [client.successEmbed(`Message sent to ${channel}.`)] });
    }
    await message.delete().catch(() => {});
  }
};
