const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'avatar',
  aliases: ['av', 'pfp', 'icon'],
  description: 'Get a user\'s avatar',
  usage: '[@user]',
  category: 'utility',
  async execute(message, args, client) {
    const target = message.mentions.users.first() || message.guild.members.cache.get(args[0])?.user || message.author;

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`${target.tag}'s Avatar`)
      .setImage(target.displayAvatarURL({ dynamic: true, size: 1024 }))
      .addFields(
        { name: 'Links', value: `[PNG](${target.displayAvatarURL({ format: 'png', size: 1024 })}) | [JPG](${target.displayAvatarURL({ format: 'jpg', size: 1024 })}) | [WEBP](${target.displayAvatarURL({ format: 'webp', size: 1024 })})` }
      );

    message.reply({ embeds: [embed] });
  }
};
