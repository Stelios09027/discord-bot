const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping',
  description: 'Check bot latency',
  category: 'utility',
  async execute(message, args, client) {
    const sent = await message.reply({ embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription('🏓 Pinging...')] });

    const latency = sent.createdTimestamp - message.createdTimestamp;
    const apiLatency = Math.round(client.ws.ping);

    sent.edit({ embeds: [new EmbedBuilder()
      .setColor(latency < 200 ? '#57F287' : latency < 500 ? '#FEE75C' : '#ED4245')
      .setTitle('🏓 Pong!')
      .addFields(
        { name: 'Bot Latency', value: `${latency}ms`, inline: true },
        { name: 'API Latency', value: `${apiLatency}ms`, inline: true }
      )
    ]});
  }
};
