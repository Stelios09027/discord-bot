'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

/** Rebuild the compiled regex from the bad-word list. */
function rebuildRegex(config) {
  if (!config.badWords?.length) {
    config.badWordRegex = null;
    return;
  }
  const escaped = config.badWords.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  config.badWordRegex = new RegExp(`\\b(${escaped.join('|')})\\b`, 'i');
}

module.exports = {
  name: 'automod',
  aliases: ['am'],
  description: 'Configure the AutoMod system',
  usage: 'status | enable <feature|all> | disable <feature|all> | badwords <add|remove|list> [word] | spamthreshold <2-20>',
  permissions: PermissionFlagsBits.ManageGuild,
  category: 'automod',

  async execute(message, args, client) {
    if (!client.automod.has(message.guild.id)) client.automod.set(message.guild.id, {});
    const config = client.automod.get(message.guild.id);
    const sub    = args[0]?.toLowerCase();

    const FEATURES = {
      antispam:   'antiSpam',
      antiinvite: 'antiInvite',
      anticaps:   'antiCaps',
    };

    // ── enable / disable ──────────────────────────────────────────────────────
    if (sub === 'enable' || sub === 'disable') {
      const on      = sub === 'enable';
      const feature = args[1]?.toLowerCase();

      if (feature === 'all') {
        for (const key of Object.values(FEATURES)) config[key] = on;
        return message.reply({ embeds: [client.successEmbed(`${on ? 'Enabled' : 'Disabled'} all AutoMod features.`)] });
      }

      const key = FEATURES[feature];
      if (!key) {
        return message.reply({
          embeds: [client.errorEmbed(`Unknown feature. Valid options: ${Object.keys(FEATURES).join(', ')}, all`)],
        });
      }
      config[key] = on;
      return message.reply({ embeds: [client.successEmbed(`${on ? 'Enabled' : 'Disabled'} **${feature}**.`)] });
    }

    // ── badwords ──────────────────────────────────────────────────────────────
    if (sub === 'badwords' || sub === 'bw') {
      const action = args[1]?.toLowerCase();
      const word   = args[2]?.toLowerCase();

      if (action === 'add') {
        if (!word) return message.reply({ embeds: [client.errorEmbed('Provide a word to add.')] });
        if (!config.badWords) config.badWords = [];
        if (config.badWords.includes(word)) return message.reply({ embeds: [client.infoEmbed(`\`${word}\` is already on the list.`)] });
        config.badWords.push(word);
        rebuildRegex(config);
        return message.reply({ embeds: [client.successEmbed(`Added \`${word}\` to the bad-word list.`)] });
      }

      if (action === 'remove') {
        if (!word) return message.reply({ embeds: [client.errorEmbed('Provide a word to remove.')] });
        const before = config.badWords?.length ?? 0;
        config.badWords = config.badWords?.filter(w => w !== word) ?? [];
        if (config.badWords.length === before)
          return message.reply({ embeds: [client.errorEmbed(`\`${word}\` was not on the list.`)] });
        rebuildRegex(config);
        return message.reply({ embeds: [client.successEmbed(`Removed \`${word}\` from the bad-word list.`)] });
      }

      if (action === 'list') {
        return message.reply({
          embeds: [client.infoEmbed(
            config.badWords?.length
              ? `**Bad words (${config.badWords.length}):**\n${config.badWords.map(w => `\`${w}\``).join(', ')}`
              : 'No bad words set.',
          )],
        });
      }

      return message.reply({ embeds: [client.errorEmbed('Usage: `automod badwords add|remove|list [word]`')] });
    }

    // ── spamthreshold ─────────────────────────────────────────────────────────
    if (sub === 'spamthreshold' || sub === 'threshold') {
      const val = parseInt(args[1]);
      if (isNaN(val) || val < 2 || val > 20)
        return message.reply({ embeds: [client.errorEmbed('Threshold must be between 2 and 20.')] });
      config.spamThreshold = val;
      return message.reply({ embeds: [client.successEmbed(`Spam threshold set to **${val}** messages per 5 seconds.`)] });
    }

    // ── status (default) ──────────────────────────────────────────────────────
    const tick  = v => v ? '✅ On' : '❌ Off';
    return message.reply({
      embeds: [new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🤖 AutoMod Status')
        .addFields(
          { name: 'Anti-Spam',   value: tick(config.antiSpam),   inline: true },
          { name: 'Anti-Invite', value: tick(config.antiInvite), inline: true },
          { name: 'Anti-Caps',   value: tick(config.antiCaps),   inline: true },
          { name: 'Spam Threshold', value: `${config.spamThreshold ?? 5} msgs / 5s`, inline: true },
          { name: 'Bad Words',      value: `${config.badWords?.length ?? 0} words`,   inline: true },
        )
        .setFooter({ text: 'automod enable|disable <feature|all> • automod badwords add|remove|list' })],
    });
  },
};
