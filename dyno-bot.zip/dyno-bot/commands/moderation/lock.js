const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'lock',
  aliases: ['lockdown'],
  description: 'Lock the current channel',
  permissions: PermissionFlagsBits.ManageChannels,
  async execute(message, args, client) {
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
      SendMessages: false
    });
    message.reply({ embeds: [client.successEmbed(`🔒 ${message.channel} has been locked.`)] });
  }
};
