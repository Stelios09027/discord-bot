'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'ban',
  aliases: ['b'],
  description: 'Ban a member from the server',
  usage: '<@user|ID> [deleteDays 0-7] [reason]',
  permissions: PermissionFlagsBits.BanMembers,
  category: 'moderation',
  cooldown: 5,

  async execute(message, args, client) {
    const target = message.mentions.members.first()
      ?? await message.guild.members.fetch(args[0]).catch(() => null);

    if (!target)          return message.reply({ embeds: [client.errorEmbed('Member not found.')] });
    if (!target.bannable) return message.reply({ embeds: [client.errorEmbed('I cannot ban this member (higher role or owner).')] });
    if (target.id === message.author.id) return message.reply({ embeds: [client.errorEmbed('You cannot ban yourself.')] });

    // Parse optional delete-days
    let deleteMessageSeconds = 0;
    let reasonStart = 1;
    if (args[1] && /^\d$/.test(args[1]) && Number(args[1]) <= 7) {
      deleteMessageSeconds = Number(args[1]) * 86400;
      reasonStart = 2;
    }
    const reason = args.slice(reasonStart).join(' ') || 'No reason provided';

    // DM the user before banning
    await target.user.send({
      embeds: [new EmbedBuilder()
        .setColor('#ED4245')
        .setTitle(`Banned from ${message.guild.name}`)
        .addFields(
          { name: 'Reason',    value: reason,              inline: true },
          { name: 'Moderator', value: message.author.tag,  inline: true },
        )
        .setTimestamp()],
    }).catch(() => {});

    await target.ban({ deleteMessageSeconds, reason: `${message.author.tag}: ${reason}` });

    const embed = new EmbedBuilder()
      .setColor('#ED4245')
      .setTitle('🔨 Member Banned')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',      value: `${target.user.tag} (${target.id})`,                  inline: true },
        { name: 'Moderator', value: message.author.tag,                                    inline: true },
        { name: 'Reason',    value: reason },
        { name: 'Msgs Deleted', value: deleteMessageSeconds ? `${deleteMessageSeconds / 86400}d` : 'None', inline: true },
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
    client.modLog(message.guild, embed);
  },
};
