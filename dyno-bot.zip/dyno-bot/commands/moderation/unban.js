const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'unban',
  description: 'Unban a user by ID',
  usage: '<userID> [reason]',
  permissions: PermissionFlagsBits.BanMembers,
  async execute(message, args, client) {
    const userId = args[0];
    if (!userId) return message.reply({ embeds: [client.errorEmbed('Please provide a user ID.')] });

    const reason = args.slice(1).join(' ') || 'No reason provided';

    try {
      await message.guild.members.unban(userId, reason);
      message.reply({ embeds: [client.successEmbed(`Unbanned user \`${userId}\`.`)] });
    } catch {
      message.reply({ embeds: [client.errorEmbed('Could not unban that user. Are they banned?')] });
    }
  }
};
