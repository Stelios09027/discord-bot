'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'warnings',
  aliases: ['warns', 'infractions'],
  description: 'View all warnings for a member',
  usage: '<@user>',
  permissions: PermissionFlagsBits.ManageMessages,
  category: 'moderation',

  async execute(message, args, client) {
    const target = message.mentions.members.first()
      ?? message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [client.errorEmbed('Member not found.')] });

    const warns = client.getWarnings(message.guild.id, target.id);
    if (!warns.length) return message.reply({ embeds: [client.infoEmbed(`${target.user.tag} has no warnings.`)] });

    const lines = warns.slice(-10).map((w, i) =>
      `**#${i + 1}** ${w.reason}\n> ${w.moderator} • <t:${Math.floor(new Date(w.date) / 1000)}:d>`
    );

    message.reply({
      embeds: [new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle(`⚠️ Warnings for ${target.user.tag}`)
        .setThumbnail(target.user.displayAvatarURL())
        .setDescription(lines.join('\n\n'))
        .setFooter({ text: `${warns.length} total warning(s) • showing last 10` })],
    });
  },
};
