'use strict';

const { PermissionFlagsBits } = require('discord.js');
const TWO_WEEKS = 14 * 24 * 60 * 60 * 1000;

module.exports = {
  name: 'purge',
  aliases: ['clear', 'prune', 'clean'],
  description: 'Bulk-delete messages. Filter: bots, humans, or a specific user',
  usage: '<1-100> [bots|humans|@user]',
  permissions: PermissionFlagsBits.ManageMessages,
  category: 'moderation',
  cooldown: 5,

  async execute(message, args, client) {
    const amount = parseInt(args[0]);
    if (!amount || amount < 1 || amount > 100)
      return message.reply({ embeds: [client.errorEmbed('Please specify a number between 1 and 100.')] });

    const filterArg   = args[1]?.toLowerCase();
    const filterUser  = message.mentions.users.first();

    let messages = await message.channel.messages.fetch({ limit: 100 });

    // Apply filter
    if (filterUser)         messages = messages.filter(m => m.author.id === filterUser.id);
    else if (filterArg === 'bots')   messages = messages.filter(m => m.author.bot);
    else if (filterArg === 'humans') messages = messages.filter(m => !m.author.bot);

    // Discord only allows bulk-deleting messages < 14 days old
    messages = messages.filter(m => Date.now() - m.createdTimestamp < TWO_WEEKS);
    messages = [...messages.values()].slice(0, amount);

    if (!messages.length)
      return message.reply({ embeds: [client.errorEmbed('No eligible messages found (must be under 14 days old).')] });

    await message.delete().catch(() => {});
    const deleted = await message.channel.bulkDelete(messages, true);

    const note = await message.channel.send({
      embeds: [client.successEmbed(`🗑️ Deleted **${deleted.size}** message(s)${filterUser ? ` from ${filterUser.tag}` : filterArg ? ` (${filterArg})` : ''}.`)],
    });
    setTimeout(() => note.delete().catch(() => {}), 4000);
  },
};
