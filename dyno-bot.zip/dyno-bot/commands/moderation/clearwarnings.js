'use strict';

const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'clearwarnings',
  aliases: ['clearwarns', 'delwarns'],
  description: 'Clear all warnings for a member',
  usage: '<@user>',
  permissions: PermissionFlagsBits.ManageGuild,
  category: 'moderation',

  async execute(message, args, client) {
    const target = message.mentions.members.first()
      ?? message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [client.errorEmbed('Member not found.')] });

    const guildWarns = client.warnings.get(message.guild.id);
    if (guildWarns) guildWarns.delete(target.id);

    message.reply({ embeds: [client.successEmbed(`Cleared all warnings for **${target.user.tag}**.`)] });
  },
};
