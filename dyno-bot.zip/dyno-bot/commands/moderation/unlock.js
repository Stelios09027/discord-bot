const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'unlock',
  description: 'Unlock the current channel',
  permissions: PermissionFlagsBits.ManageChannels,
  async execute(message, args, client) {
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
      SendMessages: null
    });
    message.reply({ embeds: [client.successEmbed(`🔓 ${message.channel} has been unlocked.`)] });
  }
};
