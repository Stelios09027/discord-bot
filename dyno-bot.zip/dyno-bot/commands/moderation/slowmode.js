const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'slowmode',
  aliases: ['slow', 'sm'],
  description: 'Set channel slowmode',
  usage: '<seconds 0-21600>',
  permissions: PermissionFlagsBits.ManageChannels,
  async execute(message, args, client) {
    const secs = parseInt(args[0]);
    if (isNaN(secs) || secs < 0 || secs > 21600)
      return message.reply({ embeds: [client.errorEmbed('Please provide a value between 0 and 21600 seconds.')] });

    await message.channel.setRateLimitPerUser(secs);
    message.reply({ embeds: [client.successEmbed(secs === 0
      ? 'Slowmode has been disabled.'
      : `Slowmode set to **${secs}** second(s).`
    )]});
  }
};
