const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const timeUnits = { s: 1000, m: 60000, h: 3600000, d: 86400000 };

function parseDuration(str) {
  const match = str.match(/^(\d+)([smhd])$/i);
  if (!match) return null;
  return parseInt(match[1]) * timeUnits[match[2].toLowerCase()];
}

module.exports = {
  name: 'mute',
  aliases: ['timeout', 'to'],
  description: 'Timeout (mute) a member. Duration: 30s, 5m, 1h, 7d',
  usage: '<@user> <duration> [reason]',
  permissions: PermissionFlagsBits.ModerateMembers,
  cooldown: 5,
  async execute(message, args, client) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [client.errorEmbed('Please mention a valid member.')] });
    if (!target.moderatable) return message.reply({ embeds: [client.errorEmbed('I cannot moderate this member.')] });

    const durStr = args[1];
    if (!durStr) return message.reply({ embeds: [client.errorEmbed('Please provide a duration (e.g. `10m`, `1h`, `1d`).')]});

    const duration = parseDuration(durStr);
    if (!duration) return message.reply({ embeds: [client.errorEmbed('Invalid duration format. Use: `30s`, `5m`, `1h`, `7d`')] });
    if (duration > 2419200000) return message.reply({ embeds: [client.errorEmbed('Max timeout is 28 days.')] });

    const reason = args.slice(2).join(' ') || 'No reason provided';

    await target.timeout(duration, `${message.author.tag}: ${reason}`);

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('🔇 Member Muted')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User', value: `${target.user.tag} (${target.id})`, inline: true },
        { name: 'Moderator', value: message.author.tag, inline: true },
        { name: 'Duration', value: durStr, inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });

    const settings = client.guildSettings.get(message.guild.id);
    if (settings?.modLogChannel) {
      const ch = message.guild.channels.cache.get(settings.modLogChannel);
      if (ch) ch.send({ embeds: [embed] });
    }
  }
};
