const { EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
  name: 'lockdown',
  aliases: ['serverlock', 'lockall'],
  description: 'Lock or unlock ALL text channels in the server at once',
  usage: '<start|end> [reason]',
  permissions: PermissionFlagsBits.Administrator,
  category: 'moderation',
  cooldown: 10,
  async execute(message, args, client) {
    const action = args[0]?.toLowerCase();
    if (!['start', 'end'].includes(action)) {
      return message.reply({ embeds: [client.errorEmbed('Usage: `lockdown start|end [reason]`')] });
    }

    const reason = args.slice(1).join(' ') || 'No reason provided';
    const locking = action === 'start';

    const statusMsg = await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#FEE75C')
      .setDescription(`${locking ? '🔒' : '🔓'} ${locking ? 'Locking' : 'Unlocking'} all channels, please wait...`)
    ]});

    const textChannels = message.guild.channels.cache.filter(c =>
      c.type === ChannelType.GuildText && c.permissionsFor(message.guild.roles.everyone)
    );

    let success = 0, failed = 0;

    for (const [, channel] of textChannels) {
      try {
        await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
          SendMessages: locking ? false : null,
        });
        success++;
      } catch {
        failed++;
      }
    }

    // Announce in current channel
    const embed = new EmbedBuilder()
      .setColor(locking ? '#ED4245' : '#57F287')
      .setTitle(locking ? '🔒 Server Lockdown Active' : '🔓 Server Lockdown Lifted')
      .setDescription(locking
        ? `The server has been locked down. No one can send messages until the lockdown is lifted.`
        : `The server lockdown has been lifted. Normal messaging has resumed.`)
      .addFields(
        { name: 'Reason', value: reason, inline: true },
        { name: 'Moderator', value: message.author.tag, inline: true },
        { name: 'Channels Affected', value: `${success} succeeded, ${failed} failed`, inline: true }
      )
      .setTimestamp();

    await statusMsg.edit({ embeds: [embed] });

    // Log to mod log
    const settings = client.guildSettings.get(message.guild.id);
    if (settings?.modLogChannel) {
      const logCh = message.guild.channels.cache.get(settings.modLogChannel);
      if (logCh && logCh.id !== message.channel.id) logCh.send({ embeds: [embed] });
    }
  }
};
