const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'nick',
  aliases: ['nickname', 'setnick'],
  description: 'Change a member\'s nickname',
  usage: '<@user> [new nickname]',
  permissions: PermissionFlagsBits.ManageNicknames,
  async execute(message, args, client) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [client.errorEmbed('Please mention a valid member.')] });

    const nick = args.slice(1).join(' ') || null;

    try {
      await target.setNickname(nick);
      message.reply({ embeds: [client.successEmbed(nick
        ? `Changed **${target.user.tag}**'s nickname to **${nick}**.`
        : `Removed **${target.user.tag}**'s nickname.`
      )]});
    } catch {
      message.reply({ embeds: [client.errorEmbed('I do not have permission to change this member\'s nickname.')] });
    }
  }
};
