'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'warn',
  aliases: ['w'],
  description: 'Issue a warning to a member',
  usage: '<@user> <reason>',
  permissions: PermissionFlagsBits.ManageMessages,
  category: 'moderation',
  cooldown: 3,

  async execute(message, args, client) {
    const target = message.mentions.members.first()
      ?? message.guild.members.cache.get(args[0]);

    if (!target) return message.reply({ embeds: [client.errorEmbed('Member not found.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [client.errorEmbed('You cannot warn yourself.')] });
    if (target.user.bot) return message.reply({ embeds: [client.errorEmbed('You cannot warn a bot.')] });

    const reason = args.slice(1).join(' ');
    if (!reason) return message.reply({ embeds: [client.errorEmbed('Please provide a reason.')] });

    const warns = client.getWarnings(message.guild.id, target.id);
    warns.push({ reason, date: new Date(), moderator: message.author.tag });

    await target.user.send({
      embeds: [new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle(`⚠️ Warning — ${message.guild.name}`)
        .addFields(
          { name: 'Reason',          value: reason,              inline: true },
          { name: 'Moderator',       value: message.author.tag,  inline: true },
          { name: 'Total Warnings',  value: `${warns.length}`,   inline: true },
        )
        .setTimestamp()],
    }).catch(() => {});

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('⚠️ Member Warned')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',           value: `${target.user.tag} (${target.id})`, inline: true },
        { name: 'Moderator',      value: message.author.tag,                  inline: true },
        { name: 'Warning #',      value: `${warns.length}`,                   inline: true },
        { name: 'Reason',         value: reason },
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
    client.modLog(message.guild, embed);
  },
};
