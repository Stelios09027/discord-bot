const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'unmute',
  aliases: ['untimeout'],
  description: 'Remove a timeout from a member',
  usage: '<@user> [reason]',
  permissions: PermissionFlagsBits.ModerateMembers,
  cooldown: 5,
  async execute(message, args, client) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [client.errorEmbed('Please mention a valid member.')] });
    if (!target.isCommunicationDisabled()) return message.reply({ embeds: [client.errorEmbed('This member is not muted.')] });

    const reason = args.slice(1).join(' ') || 'No reason provided';
    await target.timeout(null, `${message.author.tag}: ${reason}`);

    message.reply({ embeds: [new EmbedBuilder()
      .setColor('#57F287')
      .setTitle('🔊 Member Unmuted')
      .addFields(
        { name: 'User', value: `${target.user.tag}`, inline: true },
        { name: 'Moderator', value: message.author.tag, inline: true }
      )
      .setTimestamp()
    ]});
  }
};
