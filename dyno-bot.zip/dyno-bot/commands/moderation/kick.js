const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'kick',
  aliases: ['k'],
  description: 'Kick a member from the server',
  usage: '<@user> [reason]',
  permissions: PermissionFlagsBits.KickMembers,
  cooldown: 5,
  async execute(message, args, client) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [client.errorEmbed('Please mention a valid member.')] });
    if (!target.kickable) return message.reply({ embeds: [client.errorEmbed('I cannot kick this member.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [client.errorEmbed('You cannot kick yourself.')] });

    const reason = args.slice(1).join(' ') || 'No reason provided';

    await target.user.send({ embeds: [new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle(`You were kicked from ${message.guild.name}`)
      .addFields({ name: 'Reason', value: reason }, { name: 'Moderator', value: message.author.tag })
      .setTimestamp()
    ]}).catch(() => {});

    await target.kick(`${message.author.tag}: ${reason}`);

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('👢 Member Kicked')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User', value: `${target.user.tag} (${target.id})`, inline: true },
        { name: 'Moderator', value: message.author.tag, inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });

    const settings = client.guildSettings.get(message.guild.id);
    if (settings?.modLogChannel) {
      const ch = message.guild.channels.cache.get(settings.modLogChannel);
      if (ch) ch.send({ embeds: [embed] });
    }
  }
};
