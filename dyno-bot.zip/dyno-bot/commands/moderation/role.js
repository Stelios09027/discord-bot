const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'role',
  aliases: ['giverole', 'removerole'],
  description: 'Add or remove a role from a member',
  usage: '<add|remove> <@user> <@role>',
  permissions: PermissionFlagsBits.ManageRoles,
  async execute(message, args, client) {
    const action = args[0]?.toLowerCase();
    if (!['add', 'remove'].includes(action))
      return message.reply({ embeds: [client.errorEmbed('Usage: `role add|remove @user @role`')] });

    const target = message.mentions.members.first();
    if (!target) return message.reply({ embeds: [client.errorEmbed('Please mention a member.')] });

    const role = message.mentions.roles.first();
    if (!role) return message.reply({ embeds: [client.errorEmbed('Please mention a role.')] });

    if (role.position >= message.member.roles.highest.position)
      return message.reply({ embeds: [client.errorEmbed('You cannot manage this role.')] });

    if (action === 'add') {
      await target.roles.add(role);
      message.reply({ embeds: [client.successEmbed(`Added **${role.name}** to ${target.user.tag}.`)] });
    } else {
      await target.roles.remove(role);
      message.reply({ embeds: [client.successEmbed(`Removed **${role.name}** from ${target.user.tag}.`)] });
    }
  }
};
