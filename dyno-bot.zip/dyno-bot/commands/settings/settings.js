'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'settings',
  aliases: ['config', 'setup'],
  description: 'View or change bot settings for this server',
  usage: '<prefix|modlog|autorole|reset> [value]',
  permissions: PermissionFlagsBits.ManageGuild,
  category: 'settings',

  async execute(message, args, client) {
    const settings = client.settings(message.guild.id);
    const sub      = args[0]?.toLowerCase();

    switch (sub) {
      case 'prefix': {
        const p = args[1];
        if (!p)          return message.reply({ embeds: [client.infoEmbed(`Current prefix: \`${settings.prefix}\``)] });
        if (p.length > 5) return message.reply({ embeds: [client.errorEmbed('Prefix must be ≤ 5 characters.')] });
        settings.prefix = p;
        return message.reply({ embeds: [client.successEmbed(`Prefix updated to \`${p}\``)] });
      }

      case 'modlog': {
        const channel = message.mentions.channels.first();
        if (!channel) return message.reply({ embeds: [client.errorEmbed('Please mention a channel.')] });
        settings.modLogChannel = channel.id;
        return message.reply({ embeds: [client.successEmbed(`Mod log → ${channel}`)] });
      }

      case 'autorole': {
        const role = message.mentions.roles.first();
        if (!role) {
          settings.autoRole = null;
          return message.reply({ embeds: [client.successEmbed('Auto-role removed.')] });
        }
        if (role.managed) return message.reply({ embeds: [client.errorEmbed('Cannot use a managed/bot role.')] });
        settings.autoRole = role.id;
        return message.reply({ embeds: [client.successEmbed(`Auto-role set to ${role}.`)] });
      }

      case 'reset': {
        client.guildSettings.set(message.guild.id, { prefix: '?' });
        return message.reply({ embeds: [client.successEmbed('Settings reset to defaults.')] });
      }

      default: {
        const modLogCh = settings.modLogChannel ? `<#${settings.modLogChannel}>` : '`Not set`';
        const autoRole = settings.autoRole      ? `<@&${settings.autoRole}>`      : '`Not set`';
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle(`⚙️  Settings — ${message.guild.name}`)
            .addFields(
              { name: 'Prefix',    value: `\`${settings.prefix}\``, inline: true },
              { name: 'Mod Log',   value: modLogCh,                 inline: true },
              { name: 'Auto Role', value: autoRole,                  inline: true },
            )
            .setFooter({ text: 'Use settings <option> [value] to change' })],
        });
      }
    }
  },
};
