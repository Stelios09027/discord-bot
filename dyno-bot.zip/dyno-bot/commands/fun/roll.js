module.exports = {
  name: 'roll',
  aliases: ['dice', 'rng'],
  description: 'Roll dice. Format: NdN (e.g. 2d6)',
  usage: '[NdN or max number]',
  category: 'fun',
  async execute(message, args, client) {
    const input = args[0] || '1d6';
    const match = input.match(/^(\d+)d(\d+)$/i);

    if (match) {
      const count = Math.min(parseInt(match[1]), 20);
      const sides = Math.min(parseInt(match[2]), 1000);
      const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
      const total = rolls.reduce((a, b) => a + b, 0);
      const rollStr = count > 1 ? `[${rolls.join(', ')}] = **${total}**` : `**${rolls[0]}**`;
      message.reply({ embeds: [client.infoEmbed(`🎲 Rolling \`${count}d${sides}\`: ${rollStr}`)] });
    } else {
      const max = parseInt(input) || 100;
      const result = Math.floor(Math.random() * max) + 1;
      message.reply({ embeds: [client.infoEmbed(`🎲 Rolled **${result}** (1-${max})`)] });
    }
  }
};
