module.exports = {
  name: 'choose',
  aliases: ['pick', 'decide'],
  description: 'Choose between options (separated by |)',
  usage: '<option1 | option2 | ...>',
  category: 'fun',
  async execute(message, args, client) {
    const options = message.content.slice(message.content.indexOf(' ') + 1).split('|').map(s => s.trim()).filter(Boolean);
    if (options.length < 2) return message.reply({ embeds: [client.errorEmbed('Please provide at least 2 options separated by `|`.')] });

    const choice = options[Math.floor(Math.random() * options.length)];
    message.reply({ embeds: [client.infoEmbed(`🤔 I choose... **${choice}**!`)] });
  }
};
