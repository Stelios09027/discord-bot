module.exports = {
  name: 'coinflip',
  aliases: ['flip', 'coin'],
  description: 'Flip a coin',
  category: 'fun',
  async execute(message, args, client) {
    const result = Math.random() > 0.5 ? 'Heads' : 'Tails';
    message.reply({ embeds: [client.infoEmbed(`🪙 The coin landed on **${result}**!`)] });
  }
};
