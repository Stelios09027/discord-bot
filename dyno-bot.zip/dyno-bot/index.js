'use strict';

const {
  Client, GatewayIntentBits, Partials,
  Collection, EmbedBuilder, PermissionFlagsBits, Events,
} = require('discord.js');
const fs   = require('fs');
const path = require('path');
require('dotenv').config();

// ─── Client ──────────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember],
  allowedMentions: { parse: ['users', 'roles'], repliedUser: true },
});

// ─── Shared State ────────────────────────────────────────────────────────────
client.commands      = new Collection();
client.cooldowns     = new Collection();
client.warnings      = new Map(); // guildId -> Map(userId, [{reason,date,mod}])
client.automod       = new Map(); // guildId -> config
client.guildSettings = new Map(); // guildId -> settings
global.reactionRoles = new Map(); // guildId -> Map(messageId, Map(emoji, roleId))
global.giveaways     = new Map(); // messageId -> giveaway

// ─── Embed helpers ───────────────────────────────────────────────────────────
client.errorEmbed   = msg => new EmbedBuilder().setColor('#ED4245').setDescription(`❌  ${msg}`);
client.successEmbed = msg => new EmbedBuilder().setColor('#57F287').setDescription(`✅  ${msg}`);
client.infoEmbed    = msg => new EmbedBuilder().setColor('#5865F2').setDescription(`ℹ️  ${msg}`);

/** Send to the guild mod-log channel, silently fails if not configured. */
client.modLog = (guild, embedObj) => {
  const chId = client.guildSettings.get(guild.id)?.modLogChannel;
  if (chId) guild.channels.cache.get(chId)?.send({ embeds: [embedObj] }).catch(() => {});
};

/** Get (or init) per-guild settings. */
client.settings = guildId => {
  if (!client.guildSettings.has(guildId)) client.guildSettings.set(guildId, { prefix: '?' });
  return client.guildSettings.get(guildId);
};

/** Get (or init) warning list for a user in a guild. */
client.getWarnings = (guildId, userId) => {
  if (!client.warnings.has(guildId)) client.warnings.set(guildId, new Map());
  const g = client.warnings.get(guildId);
  if (!g.has(userId)) g.set(userId, []);
  return g.get(userId);
};

// ─── Load Commands ────────────────────────────────────────────────────────────
const cmdRoot = path.join(__dirname, 'commands');
for (const folder of fs.readdirSync(cmdRoot)) {
  const folderPath = path.join(cmdRoot, folder);
  if (!fs.statSync(folderPath).isDirectory()) continue;
  for (const file of fs.readdirSync(folderPath).filter(f => f.endsWith('.js'))) {
    try {
      const cmd = require(path.join(folderPath, file));
      if (cmd?.name) client.commands.set(cmd.name, cmd);
    } catch (err) {
      console.error(`[CMD LOAD ERROR] ${file}: ${err.message}`);
    }
  }
}
console.log(`[BOOT] Loaded ${client.commands.size} commands.`);

// ─── Ready ────────────────────────────────────────────────────────────────────
client.once(Events.ClientReady, c => {
  console.log(`[READY] ${c.user.tag} | ${c.guilds.cache.size} guilds`);
  c.user.setActivity('?help | Dyno Bot', { type: 3 });
});

// ─── Message Handler ──────────────────────────────────────────────────────────
client.on(Events.MessageCreate, async message => {
  if (message.author.bot || !message.guild) return;

  // AutoMod sees every message (before prefix check)
  handleAutoMod(message);

  const { prefix } = client.settings(message.guild.id);
  if (!message.content.startsWith(prefix)) return;

  const args        = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  if (!commandName) return;

  const command = client.commands.get(commandName)
    ?? client.commands.find(c => c.aliases?.includes(commandName));
  if (!command) return;

  // Permission gate
  if (command.permissions && !message.member.permissions.has(command.permissions)) {
    return message.reply({ embeds: [client.errorEmbed('You lack the required permissions.')] });
  }

  // Cooldown gate
  if (!client.cooldowns.has(command.name)) client.cooldowns.set(command.name, new Map());
  const stamps = client.cooldowns.get(command.name);
  const now    = Date.now();
  const cd     = (command.cooldown ?? 3) * 1000;
  const expiry = (stamps.get(message.author.id) ?? 0) + cd;
  if (now < expiry) {
    return message.reply({
      embeds: [client.errorEmbed(`Cooldown — wait **${((expiry - now) / 1000).toFixed(1)}s** before using \`${command.name}\` again.`)],
    });
  }
  stamps.set(message.author.id, now);
  setTimeout(() => stamps.delete(message.author.id), cd);

  try {
    await command.execute(message, args, client);
  } catch (err) {
    console.error(`[CMD ERROR] ${command.name}:`, err);
    message.reply({ embeds: [client.errorEmbed('Something went wrong. Please try again.')] }).catch(() => {});
  }
});

// ─── AutoMod ──────────────────────────────────────────────────────────────────
const INVITE_RE = /discord(?:\.gg|app\.com\/invite)\/[\w-]+/i;
const _spam     = new Map(); // key -> { count, timer }

function handleAutoMod(message) {
  const config = client.automod.get(message.guild.id);
  if (!config) return;
  if (message.member.permissions.has(PermissionFlagsBits.ManageMessages)) return;

  let reason = null;

  if (!reason && config.antiInvite && INVITE_RE.test(message.content))
    reason = 'Discord invite link';

  if (!reason && config.badWordRegex?.test(message.content.toLowerCase()))
    reason = 'Prohibited word';

  if (!reason && config.antiCaps) {
    const letters = message.content.replace(/[^a-zA-Z]/g, '');
    if (letters.length >= 10) {
      const uppers = letters.split('').filter(c => c >= 'A' && c <= 'Z').length;
      if (uppers / letters.length >= 0.7) reason = 'Excessive caps';
    }
  }

  if (!reason && config.antiSpam) {
    const key    = `${message.guild.id}:${message.author.id}`;
    const bucket = _spam.get(key) ?? { count: 0, timer: null };
    bucket.count++;
    clearTimeout(bucket.timer);
    bucket.timer = setTimeout(() => _spam.delete(key), 5000);
    _spam.set(key, bucket);
    if (bucket.count >= (config.spamThreshold ?? 5)) {
      reason = 'Spam detected';
      _spam.delete(key);
    }
  }

  if (!reason) return;

  message.delete().catch(() => {});
  message.channel
    .send({ embeds: [client.errorEmbed(`${message.author}, message removed: **${reason}**`)] })
    .then(m => setTimeout(() => m.delete().catch(() => {}), 5000))
    .catch(() => {});

  client.modLog(
    message.guild,
    new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('🤖 AutoMod Action')
      .addFields(
        { name: 'User',    value: `${message.author.tag} (${message.author.id})`, inline: true },
        { name: 'Reason',  value: reason,                                          inline: true },
        { name: 'Channel', value: `${message.channel}`,                            inline: true },
        { name: 'Content', value: message.content.slice(0, 1000) || '—' },
      )
      .setTimestamp(),
  );
}

// ─── Reaction Roles ───────────────────────────────────────────────────────────
async function handleReaction(reaction, user, add) {
  if (user.bot) return;
  try { if (reaction.partial) await reaction.fetch(); } catch { return; }

  const { guild } = reaction.message;
  if (!guild) return;

  const rrMap = global.reactionRoles.get(guild.id)?.get(reaction.message.id);
  if (!rrMap) return;

  const emoji  = reaction.emoji.id
    ? `<${reaction.emoji.animated ? 'a' : ''}:${reaction.emoji.name}:${reaction.emoji.id}>`
    : reaction.emoji.name;
  const roleId = rrMap.get(emoji);
  if (!roleId) return;

  const [member, role] = await Promise.all([
    guild.members.fetch(user.id).catch(() => null),
    Promise.resolve(guild.roles.cache.get(roleId)),
  ]);
  if (!member || !role) return;

  (add ? member.roles.add(role) : member.roles.remove(role)).catch(() => {});
}

client.on(Events.MessageReactionAdd,    (r, u) => handleReaction(r, u, true));
client.on(Events.MessageReactionRemove, (r, u) => handleReaction(r, u, false));

// ─── Auto-role on join ────────────────────────────────────────────────────────
client.on(Events.GuildMemberAdd, member => {
  const roleId = client.guildSettings.get(member.guild.id)?.autoRole;
  if (!roleId) return;
  const role = member.guild.roles.cache.get(roleId);
  if (role) member.roles.add(role).catch(() => {});
});

// ─── Process error resilience ────────────────────────────────────────────────
client.on('error', err => console.error('[CLIENT ERROR]', err));
process.on('unhandledRejection', err => console.error('[UNHANDLED REJECTION]', err));

client.login(process.env.BOT_TOKEN);
