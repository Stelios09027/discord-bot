# 🤖 Dyno-Like Discord Bot

A feature-rich Discord bot inspired by Dyno with moderation, utility, fun, and auto-moderation features.

## ✨ Features

- 🛡️ **Moderation** — ban, kick, mute, warn, purge, lock, slowmode, role management
- 🔧 **Utility** — userinfo, serverinfo, avatar, poll, embed, announce, ping
- 🎉 **Fun** — 8ball, coinflip, dice roll, choose
- 🤖 **AutoMod** — anti-spam, anti-invite, anti-caps, bad word filter
- ⚙️ **Settings** — per-server prefix, mod log, welcome/leave messages, auto-role

---

## 🚀 Setup

### 1. Prerequisites
- [Node.js](https://nodejs.org/) v18 or higher
- A Discord bot token from the [Developer Portal](https://discord.com/developers/applications)

### 2. Installation

```bash
git clone <your-repo>
cd dyno-bot
npm install
```

### 3. Configuration

```bash
cp .env.example .env
```

Edit `.env` and add your bot token:
```
BOT_TOKEN=your_actual_bot_token_here
```

### 4. Discord Developer Portal Setup

1. Go to https://discord.com/developers/applications
2. Create a New Application
3. Go to **Bot** tab → Add Bot
4. Enable these **Privileged Gateway Intents**:
   - ✅ Server Members Intent
   - ✅ Message Content Intent
   - ✅ Presence Intent
5. Copy your **Bot Token** → paste into `.env`
6. Go to **OAuth2 → URL Generator**
7. Scopes: `bot`
8. Bot Permissions: `Administrator` (or select individual permissions)
9. Copy the generated URL and invite the bot to your server

### 5. Start the Bot

```bash
npm start
# or for development with auto-restart:
npm run dev
```

---

## 📋 Commands

Default prefix: `?`  
Change per-server with: `?settings prefix <new_prefix>`

### 🛡️ Moderation
| Command | Description | Usage |
|---------|-------------|-------|
| `ban` | Ban a member | `?ban @user [days] [reason]` |
| `unban` | Unban a user | `?unban <userID> [reason]` |
| `kick` | Kick a member | `?kick @user [reason]` |
| `mute` | Timeout a member | `?mute @user <10m/1h/7d> [reason]` |
| `unmute` | Remove timeout | `?unmute @user` |
| `warn` | Warn a member | `?warn @user <reason>` |
| `warnings` | View warnings | `?warnings @user` |
| `clearwarnings` | Clear all warnings | `?clearwarnings @user` |
| `purge` | Delete messages | `?purge <1-100> [@user]` |
| `slowmode` | Set slowmode | `?slowmode <0-21600>` |
| `lock` | Lock channel | `?lock` |
| `unlock` | Unlock channel | `?unlock` |
| `role` | Add/remove role | `?role add|remove @user @role` |
| `nick` | Change nickname | `?nick @user [new name]` |

### 🔧 Utility
| Command | Description | Usage |
|---------|-------------|-------|
| `help` | List commands | `?help [command]` |
| `userinfo` | User info | `?userinfo [@user]` |
| `serverinfo` | Server info | `?serverinfo` |
| `avatar` | Get avatar | `?avatar [@user]` |
| `poll` | Create a poll | `?poll Question \| Option1 \| Option2` |
| `embed` | Send embed | `?embed [#channel] <message>` |
| `announce` | Announcement | `?announce [#channel] <message>` |
| `ping` | Check latency | `?ping` |

### 🎉 Fun
| Command | Description | Usage |
|---------|-------------|-------|
| `8ball` | Magic 8-ball | `?8ball <question>` |
| `coinflip` | Flip a coin | `?coinflip` |
| `roll` | Roll dice | `?roll 2d6` |
| `choose` | Pick an option | `?choose A \| B \| C` |

### 🤖 AutoMod
| Command | Description |
|---------|-------------|
| `?automod` | View status |
| `?automod enable antispam\|antiinvite\|anticaps\|all` | Enable features |
| `?automod disable <feature>` | Disable features |
| `?automod badwords add <word>` | Add bad word |
| `?automod badwords remove <word>` | Remove bad word |
| `?automod badwords list` | List bad words |
| `?automod spamthreshold <2-20>` | Set spam threshold |

### ⚙️ Settings
| Command | Description |
|---------|-------------|
| `?settings` | View all settings |
| `?settings prefix <prefix>` | Change prefix |
| `?settings modlog #channel` | Set mod log channel |
| `?settings welcome #channel [message]` | Set welcome channel |
| `?settings leave #channel` | Set leave channel |
| `?settings autorole @role` | Set auto-role for new members |

---

## ⚠️ Notes

- **Warnings are stored in memory** — they reset when the bot restarts. Add a database (MongoDB/SQLite) for persistence.
- **AutoMod and server settings** are also stored in memory. Consider adding a database for production.
- The bot requires `ManageMessages` to delete messages, `BanMembers` to ban, etc.

## 🗄️ Adding a Database (Optional but Recommended)

For persistent data, install `mongoose` or `better-sqlite3`:
```bash
npm install mongoose
```
Then replace `client.warnings`, `client.guildSettings`, and `client.automod` with database calls.

---

## 📄 License
MIT
